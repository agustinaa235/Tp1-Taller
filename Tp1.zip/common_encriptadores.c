#include "common_encriptadores.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>


#define EXITO 0
#define TAMANIO_VECTOR_S 256
#define CESAR "cesar"
#define VIGENERE "vigenere"
#define RC4 "rc4"


int encriptador_inicializar(encriptador_t *self,
                            char* key,
                            int (*funcion)(unsigned char*, char*, int)){
    self->key = key;
    self->funcion = funcion;
    return EXITO;
}

int cesar(unsigned char* mensaje, int key, int tamanio){
    int i = 0;
    while (i<tamanio){
      mensaje[i] = (mensaje[i] + key) % TAMANIO_VECTOR_S;
      i++;
    }
    return EXITO;
}

int cifrado_cesar(unsigned char* mensaje, char* key, int tamanio){
    int key_aux = 0;
    key_aux = atoi(key);
    return cesar(mensaje, key_aux, tamanio);
}

int descifrar_cesar(unsigned char* mensaje, char* key, int tamanio){
    int key_aux = 0;
    key_aux = atoi(key);
    int i = 0;
    while (i<tamanio){
      mensaje[i] = (mensaje[i] - key_aux) %TAMANIO_VECTOR_S;

      i++;
    }
    return EXITO;
}

int cifrado_vigenere(unsigned char* mensaje, char* key, int tamanio){
    int i = 0;
    int j = 0;
    while (i< tamanio){
      if (j == strlen(key)){
          j = 0;
      }
      mensaje[i] = (mensaje[i] + key[j]) % TAMANIO_VECTOR_S;
      printf("|%x|", (int)mensaje[i]);

      i++;
      j++;
  }
  return EXITO;
}

int descrifrado_vigenere(unsigned char* mensaje, char* key, int tamanio){
    int i = 0;
    int j = 0;
    while (i< tamanio){
        if (j == strlen(key)){
            j = 0;
        }
        mensaje[i] = (mensaje[i] - key[j])% TAMANIO_VECTOR_S;
        i++;
        j++;
    }
    return EXITO;
}

void swap(unsigned char* s_box, int j, int k) {
    unsigned char aux = s_box[j];
    s_box[j] = s_box[k];
    s_box[k] = aux;
}

unsigned char rc4_prga(unsigned char* s_box, int* j, int* k) {
    *j = (*j + 1) % TAMANIO_VECTOR_S;
    *k = (*k + s_box[*j])%TAMANIO_VECTOR_S;
    swap(s_box, *j, *k);
    return s_box[((s_box[*j] + s_box[*k]) % TAMANIO_VECTOR_S)];
}
void rc4_ksa(char* key, size_t tamanio_key, unsigned char* s_box){
    int j = 0;
    for (int i = 0; i < (TAMANIO_VECTOR_S -0); i++){
        s_box[i] = i;
    }
    for (int x = 0; x < (TAMANIO_VECTOR_S -0); x++) {
        j = (j + key[x % tamanio_key] + s_box[x])%TAMANIO_VECTOR_S;
        swap(s_box, x, j);
    }
}

int cifrado_rc4(unsigned char* mensaje, char* key, int tamanio){
    unsigned char s_box[TAMANIO_VECTOR_S];
    int i = 0;
    int j = 0;
    int k = 0;
    rc4_ksa(key, strlen(key), s_box);
    while (i< tamanio){
        mensaje[i] = mensaje[i]^rc4_prga(s_box, &j, &k);
        printf("| %x|", (int)mensaje[i]);
        i++;
    }
    printf("\n");
    return EXITO;
}

int encriptador_encriptar(encriptador_t *self, unsigned char* mensaje,
                          int tamanio){
      return self->funcion(mensaje, self->key, tamanio);
}
int encriptador_desencriptar(encriptador_t* self, unsigned char* mensaje,
                             int tamanio){
      return self->funcion(mensaje, self->key, tamanio);
}
